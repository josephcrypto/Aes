package www.dv16888.aes;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("www.dv16888.aes")
public class EncryptAutoConfiguration {

}
