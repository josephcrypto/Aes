package www.dv16888.aes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AesApplicationTests {

    @Test
    void contextLoads() {
    }

}
